^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package micro_ros_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2021-08-30)
------------------
* Remove not necessary dependencies (`#1 <https://github.com/micro-ROS/micro_ros_msgs/issues/1>`_)
* Add issue template
* Add msg definitions used by micro-ROS graph manager
* Update README.md
